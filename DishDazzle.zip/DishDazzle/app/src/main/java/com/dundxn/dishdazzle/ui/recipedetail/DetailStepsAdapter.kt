package com.dundxn.dishdazzle.ui.recipedetail

class DetailStepsAdapter {
}